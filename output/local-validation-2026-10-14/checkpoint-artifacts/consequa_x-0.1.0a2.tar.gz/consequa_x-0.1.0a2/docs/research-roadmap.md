# Research and release roadmap

The current milestone is an installable representation and bounded policy replay prototype. Scripted fixtures establish that response, reported assessment and observed state can diverge, and that context can change a consequence while leaving the initial action unchanged. The policy integration prepares these experiments for an installed local model. It does not establish a novel attribution estimator or publishable empirical superiority.

The initial literature assessment is in `output/research/Consequa-X_Research_Assessment.md` (reviewed 4 October 2026). Before a submission, refresh paper versions and related work, particularly CausalLoss-Fin, CAR, PCCC, FinalityBench and ConsequenceBench.

## Completed foundation

- Versioned public records and portable JSON Schema.
- Deterministic refund environment, audited fault log, bounded funds and idempotency.
- Read-only, horizon-aware verification with independent origin status.
- Evidence graph and reported-assessment diagnosis.
- Recency heuristic and paired leave-one-out effect estimates.
- Separate demo trace, explanation and evaluator-truth exports.
- Offline deterministic and stochastic programmatic policy experiments.
- Visible-context policy interface, structured local Ollama adapter, and bounded evaluations.
- Bounded paired policy experiments with one factual branch per seed, cached action/consequence estimates, and explicit refusals for incomplete pairs.
- Scripted policy smoke exports, HTTP fixture tests, and a [first live Qwen3 4B pilot](../output/live-pilot-2026-10-10/README.md).
- Versioned opt-in prompt refinement with the original profile preserved, and assessment coverage/abstention metrics with explicit denominators.
- Audited [prompt-sensitivity follow-up](../output/prompt-sensitivity-2026-10-10/README.md): 12 controlled one-attempt runs and a separate two-episode retry diagnostic. The opt-in profile abstained in the structured field while still making affirmative rationale claims; no accuracy improvement was established.
- Proposed matched-baseline study protocol in [study-plan.md](study-plan.md).
- Validated evaluator-owned task-family manifests with explicit split and order metadata; an 18-case candidate allocation is available in [study-manifests.md](study-manifests.md).
- A supported action-linked refund target distinct from state satisfaction, plus [decision-prefix replay](decision-replay.md) with factual boundary checks and separate continuation seeds.
- Independent CAR-style [decision contrastive replay](decision-contrastive.md) with one observed factual baseline, explicit bootstrap limits, and complete-coverage locus/refusal receipts.
- Conservative [positional coalition and Shapley replay](decision-shapley.md), with fresh antithetic walks, signed pair estimates, independent endpoint diagnostics, and unavailable-coalition refusal.
- An offline [attribution calibration probe](attribution-calibration.md) with predeclared synthetic mechanisms, separate analytic references, repeated error/coverage scoring, and complete refusal denominators.
- An audited [1,280-trial calibration run](../output/calibration-probe-2026-10-11/FINDINGS.md), [finite interval enumeration](../output/calibration-theory-2026-10-11/README.md), and fresh [384-trial same-draw comparison](../output/interval-comparison-2026-10-13/FINDINGS.md). Conservative interval defaults retain uncertainty at constant observations, with width and detection tradeoffs explicit.
- Separate strict and [on-reach positional games](decision-shapley.md), plus [physical refund selection/retry interactions](refund-interactions.md), idempotency and evidence/budget controls. Exact component enumeration establishes the declared physical game; repeated permutation-sampler calibration remains separate.
- A [working manuscript and evidence ledger](../paper/README.md), with completed preliminary evidence and pending held-out, matched-baseline and joint-fault experiments identified.

## Next research milestone

1. Extend the recorded local pilot to actual stochastic LLM policies across several task templates and models. The adapter exposes declared task/context and public responses; independent readback follows the final assessment, and evaluator truth stays outside policy inputs. Measure replay fidelity rather than treating shared requested seeds as a determinism guarantee. Prompt changes informed by the pilot are exploratory adaptations and need independent held-out evaluation.
2. Specify context and fault intervention families and targets before running the study. Hold out templates and fault compositions, not just random seeds.
3. Extend repeated sampler calibration beyond the exact physical interaction enumeration, then compare the [CAR adaptations](car-reproduction-plan.md) with identical evidence, origin information, intervention units, snapshots and budget. Conservative interval defaults address the previous homogeneous-sample collapse; they do not establish live-model coverage or resolve undefined strict games. Report unavailable coalitions and sampling assumptions, and add a faithfully adapted joint context/fault comparator.
4. Measure false consequence/origin claims and factor recovery against independent intervention estimates. Report abstention coverage and error together; audit rationale assertions separately from structured status and report model-specific results and cost.
5. Expand domains only after a substantive gap remains in the strong baseline. An engineering framework can still be released if the methodological advantage does not emerge.

The current 40-sample fixture report, scripted policy smoke report, and scripted paired-policy examples validate plumbing. They cannot be used as real-model research results. The first live pilot completed six runs and 13 policy calls without provider errors; all six final assessments contradicted successful action-linked readback. The recency heuristic is explicitly noncausal, and leave-one-out is a baseline rather than a claimed new estimator. Current paired policy experiments change one visible context field at a time; joint context/fault analysis and the strong comparison methods remain unimplemented research milestones. See [policy-evaluation.md](policy-evaluation.md) and [policy-replay.md](policy-replay.md) for entry points. All payment effects remain simulated.

## Registry release

The first distribution target is Python/PyPI. The local distribution name is `consequa-x`; registry availability and account ownership are unverified. A TypeScript/npm adapter can later share the schema and conformance fixtures without duplicating the Python estimators.

The public source repository uses the MIT license and includes author metadata and contribution guides. GitHub Actions is disabled at the maintainer's request; validation and builds run locally. The source retains its Python 3.11/3.12 compatibility declarations, while new checks must identify the actual tested hosts/interpreters. See [release readiness](release-readiness.md) for artifact, ownership and authentication requirements. No PyPI/npm upload or package ownership claim is made by the source version alone.

The selected workspace contains no existing Consequa runtime. Integration with that runtime requires the source repository and compatibility checks, rather than a rewrite based on the brief's assumed architecture.
